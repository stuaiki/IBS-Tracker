// Authors: Aiki Takaku, Mark Barlocker, Spencer Olson, David Winn
// The index.js file is where all the routing takes place. 
// This allows for navigation from one page to another while passing data. 
// This also connects to our database.



const express = require("express");
const { platform } = require("os");
let app = express();
let path = require("path")

const port = process.env.PORT || 3000;

app.set("view engine", "ejs");
app.use(express.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname, 'public')));


const knex = require("knex")({
    client: "pg",
    connection: {
        host: process.env.RDS_HOSTNAME || "localhost",
        user: process.env.RDS_USERNAME || "postgres",
        password: process.env.RDS_PASSWORD|| "Priesthood12",
        database: process.env.RDS_DB_NAME || "local_ibs",
        port: process.env.RDS_PORT || 5432,
        ssl: process.env.DB_SSL ? {rejectUnauthorized: false} : false
    }
});

app.listen(port, () => console.log("My server is listening"));

app.get('/', (req, res) => {
    res.render("landingPage");
});

app.get('/login', (req, res) => {
    res.render("login");
});

app.get('/foodForm', (req, res) => {
    res.render('foodForm');
});

app.post('/loginAccount', (req, res) => {
    

    knex.select()
        .from("user")
        .where({ username: req.body.user, password: req.body.password })
        .first()
        .then(foundUser => {
            if (foundUser) {
                res.redirect('/listView/' + foundUser.user_id)
            } else {
                return res.status(404).send('User not found');
            }
        })
        .catch(err => {
            console.error(err);
            res.status(500).send('Internal Server Error');
        });
});

app.get('/listView/:id', (req, res) => {
    knex.select()
        .from("user")
        .where('user_id', req.params.id)
        .first()
        .then(foundUser => {
            if (foundUser) {
                // Query foodList and sympList
                const foodListPromise = knex.select()
                    .from("food_entry")
                    .where("user_id", foundUser.user_id);

                const sympListPromise = knex.select()
                    .from("symptom_entry")
                    .where("user_id", foundUser.user_id);

                // Wait for all promises to resolve
                return Promise.all([foodListPromise, sympListPromise])
                    .then(([foodList, sympList]) => {
                        res.render('listView', { user: foundUser, foodList, sympList });
                    });
            } else {
                return res.status(404).send('User not found');
            }
        })
        .catch(err => {
            console.error(err);
            res.status(500).send('Internal Server Error');
        });
});

app.get('/foodForm/:id', (req, res) => {
    res.render('foodForm', {user: req.params.id})
})

app.get('/painEntry/:id', (req, res) => {
    res.render('painEntry', {user: req.params.id});
});

app.post('/createFoodEntry/:id', (req, res) => {
    let foodList = [];
    if(typeof req.body.foodType === 'string') {
        foodList.push(req.body.foodType);
    } else if (req.body.foodType === undefined){
        foodList.push('N/A');
    } else {
        foodList = req.body.foodType;
    }
    knex('food_entry')
    .where('user_id', req.params.id)
    .insert({
        description: req.body.food_desc,
        date: req.body.date,
        time: req.body.time,
        food_type: foodList,
        user_id: req.params.id
    }).then(() => {
        // Redirect on success
        res.redirect('/listView/' + parseInt(req.params.id));
      })
      .catch((err) => {
        // Handle errors
        console.error(err);
        res.status(500).json({ err });
      });
});

app.post('/createPainEntry/:id', (req, res) => {
    let symptomList = [];
    if(typeof req.body.symptom === 'string') {
        symptomList.push(req.body.symptom);
    } else if (req.body.symptom === undefined){
        symptomList.push('N/A');
    } else {
        symptomList = req.body.symptom;
    }
    knex('symptom_entry')
    .where('user_id', req.params.id)
    .insert({
        description: req.body.painDesc,
        date: req.body.date,
        time: req.body.time,
        pain_level: req.body.painLevel,
        symptoms: symptomList,
        user_id: req.params.id
    }).then(() => {
        // Redirect on success
        res.redirect('/listView/' + parseInt(req.params.id));
      })
      .catch((err) => {
        // Handle errors
        console.error(err);
        res.status(500).json({ err });
      });
});

app.post('/updatePainEntry/:id/:userId', (req, res) => {
    let symptomList = [];
    if(typeof req.body.symptom === 'string') {
        symptomList.push(req.body.symptom);
    } else if (req.body.symptom === undefined){
        symptomList.push('N/A');
    } else {
        symptomList = req.body.symptom;
    }
    knex('symptom_entry')
    .where('symp_id', req.params.id)
    .update({
        description: req.body.painDesc,
        date: req.body.date,
        time: req.body.time,
        pain_level: req.body.painLevel,
        symptoms: symptomList,
        user_id: req.params.userId
    }).then(() => {
        // Redirect on success
        res.redirect('/listView/' + parseInt(req.params.userId));
      })
      .catch((err) => {
        // Handle errors
        console.error(err);
        res.status(500).json({ err });
      });
});

app.post('/updateFoodEntry/:id/:userId', (req, res) => {
    let foodList = [];
    if(typeof req.body.foodType === 'string') {
        foodList.push(req.body.foodType);
    } else if (req.body.foodType === undefined){
        foodList.push('N/A');
    } else {
        foodList = req.body.foodType;
    }
    knex('food_entry')
    .where('food_id', req.params.id)
    .update({
        description: req.body.food_desc,
        date: req.body.date,
        time: req.body.time,
        food_type: foodList,
        user_id: req.params.userId
    }).then(() => {
        // Redirect on success
        res.redirect('/listView/' + parseInt(req.params.userId));
      })
      .catch((err) => {
        // Handle errors
        console.error(err);
        res.status(500).json({ err });
      });
});



app.post('/deletePainEntry/:id/:userId', (req, res) => {
    knex('symptom_entry').where('symp_id', req.params.id).del()
    .then(() => {
        res.redirect('/listView/' + parseInt(req.params.userId));
      })
      .catch((err) => {
        console.error(err);
        res.status(500).json({ err });
      });
});

app.post('/deleteFoodEntry/:id/:userId', (req, res) => {
    knex('food_entry').where('food_id', req.params.id).del()
    .then(() => {
        res.redirect('/listView/' + parseInt(req.params.userId));
      })
      .catch((err) => {
        console.error(err);
        res.status(500).json({ err });
      });
});

app.get('/editFoodEntry/:id/:userId', (req, res) => {
    const foodId = parseInt(req.params.id);
    const userId = parseInt(req.params.userId);

    knex.select().from('food_entry')
        .where('food_id', foodId)
        .andWhere('user_id', userId)
        .then(formEntry => {
            if (formEntry.length === 0) {
                // Food entry with the specified foodId does not exist
                res.status(404).send('Food entry not found');
                return;
            }
            // Render the editForm template with formEntry and userId
            res.render('editForm', { formEntry: formEntry, userId: userId });
        })
        .catch(error => {
            console.error(error);
            res.status(500).send('Internal Server Error');
        });
});



  
  app.get('/editSympEntry/:id/:userId', (req, res) => {
    const sympId = parseInt(req.params.id);
    const userId = parseInt(req.params.userId);

    knex.select().from('symptom_entry')
        .where('symp_id', sympId)
        .then(formEntry => {
            if (formEntry.length === 0) {
                // Food entry with the specified foodId does not exist
                res.status(404).send('Food entry not found');
                return;
            }

            // Check if the userId exists in the user table
            knex('user')
                .where('user_id', userId)
                .then(users => {
                    if (users.length === 0) {
                        // User with the specified userId does not exist
                        res.status(404).send('User not found');
                        return;
                    }

                    // Render the editForm template with formEntry and userId
                    res.render('editSymp', { formEntry: formEntry, userId: userId });
                })
                .catch(error => {
                    console.error(error);
                    res.status(500).send('Internal Server Error');
                });
        })
        .catch(error => {
            console.error(error);
            res.status(500).send('Internal Server Error');
        });
});

app.post('/createAccount', (req, res) => {
    const {fname, lname, email, username, passwordCreate, theme} = req.body;

    knex('user')
            .where('username', username)
            .first()
            .then(existingUser => {
                if (existingUser) {
                    return false;
                } 
                else {
                    knex('user')
                        .insert({
                            first_name: fname,
                            last_name: lname,
                            email: email,
                            username: username,
                            password: passwordCreate,
                            theme: theme
                        })
                        .then(record => {
                            res.redirect('login');
                        })
                        .catch(err => {
                            console.error(err);
                            res.status(500).send('Internal Server Error');
                        }); 
                }
            })
            .catch(err => {
                console.error(err);
                res.status(500).send('Internal Server Error');
            });
    });
