const today = new Date();

const year = today.getFullYear();
let month = today.getMonth() + 1;
let day = today.getDate();

if (month < 10) {
  month = '0' + month;
}
if (day < 10) {
  day = '0' + day;
}

const formattedDate = `${year}-${month}-${day}`;
document.getElementById('date').value = formattedDate;



const now = new Date();

let hours = now.getHours();
let minutes = now.getMinutes();

if (hours < 10) {
  hours = '0' + hours;
}
if (minutes < 10) {
  minutes = '0' + minutes;
}

const formattedTime = `${hours}:${minutes}`;
document.getElementById('time').value = formattedTime;


let asDataDesc = []
let asFoodType = []
let sOutput = ""

class FoodEntry
{
    constructor()
    {
        this.food_description;
        this.date;
        this.time;
    }
}


function submitData()
{
    let sFoodDescription = document.getElementById("foodDesc").value
    let Date = document.getElementById("date").value
    let Time = document.getElementById("time").value
    let 

    sOutput = sFoodDescription + " " + "<br>Date: " + Date + "<br>Time: " + Time

    document.getElementById("show").innerHTML = sOutput
}
