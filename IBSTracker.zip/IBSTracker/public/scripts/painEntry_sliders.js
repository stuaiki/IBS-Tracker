function sizeForpainLevel(iSize) 
{
    document.getElementById("painLevel").innerHTML = iSize;
}