// these are event handlers and to collect information user need to make filters
document.addEventListener('DOMContentLoaded', function() {
    const searchInputFood = document.getElementById('searchInputFood');
    const tableRowsFood = document.querySelectorAll('#foodTable tbody tr');
    // searchInput.addEventListener('input', applyFilters);
    searchInputFood.addEventListener('input', () => applyFilters(searchInputFood, tableRowsFood));

    const searchInputPain = document.getElementById('searchInputPain');
    const tableRowsPain = document.querySelectorAll('#painTable tbody tr');
    searchInputPain.addEventListener('input', () => applyFilters(searchInputPain, tableRowsPain));

    // this function search and apply filter for user to see specific data they want to get.
    //search their input and see if there are matched data
    function applyFilters(searchInput, tableRows) {
        const searchText = searchInput.value.toLowerCase();

        tableRows.forEach(function(row) {
            const cells = row.querySelectorAll('td');
            let textMatch = true;
            // Check if the row matches the search text
            if (searchText) {
                textMatch = false;
                cells.forEach(function(cell) {
                    if (cell.textContent.toLowerCase().includes(searchText)) {
                        textMatch = true;
                    }
                });
            }

            // Show or hide the row based on search match
            if (textMatch) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
});