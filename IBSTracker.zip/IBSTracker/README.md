# IBSTracker
A website to help people track their IBS symptoms


# Git Commands

Create a new branch: 
git checkout -b "branch_name"

Switch Branches:
git checkout branch_name

Push your code:
git add .
git commit -m "commit message"
git push

Pull code:
git pull
If that doesn't work, do git fetch, then git pull

Color Scheme:
Blue: #3689ff use for accent color (buttons and stuff)
Off-White: #fbfcff use for backgrounds
Gray: #263043 use for text
Other Blue: #086fff Hover color for buttons

Font
font-family: Arial, sans-serif;